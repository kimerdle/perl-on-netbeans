/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.dev.languages.perl.actions;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.IOException;
import org.dev.languages.perl.compiler.PerlParser;
import org.dev.languages.perl.filetype.PerlDataObject;
import org.openide.cookies.SaveCookie;
import org.openide.util.Exceptions;

public final class ParseAction implements ActionListener {

    private final PerlDataObject context;

    public ParseAction(PerlDataObject context) {
        this.context = context;
    }

    @Override
    public void actionPerformed(ActionEvent ev) {
        if (context.isModified() == true)
        {
            //Save the file before checking for syntax errors
            SaveCookie sc = context.getCookie(SaveCookie.class);
            try {
                sc.save();
            } catch (IOException ex) {
                Exceptions.printStackTrace(ex);
            }
        }

        PerlParser parser = new PerlParser();
        parser.parseDataObject(context);
    }
}
