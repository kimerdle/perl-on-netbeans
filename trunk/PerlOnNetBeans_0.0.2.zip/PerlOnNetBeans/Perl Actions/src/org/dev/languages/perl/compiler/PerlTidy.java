/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.dev.languages.perl.compiler;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.openide.filesystems.FileUtil;
import org.openide.loaders.DataObject;
import org.openide.util.Exceptions;
import org.openide.windows.IOProvider;
import org.openide.windows.InputOutput;
import org.openide.windows.OutputWriter;

/**
 *
 * @author Administrator
 */
public class PerlTidy {
    DataObject dataObject;
    String fileName;

    public PerlTidy() {
        this.dataObject = null;
    }

    public void tidyDataObject(DataObject dObj) {
        ProcessBuilder procBuilder;
        Process process;
        Map<String, String> env;

        List<String> cmd;
        String line;
        InputOutput io;
        OutputWriter outputWriter;

        this.dataObject = dObj;
        File file = FileUtil.toFile(dObj.getPrimaryFile());
        fileName = file.getAbsolutePath();

        io = IOProvider.getDefault().getIO("Perl", false);
        io.select();
        outputWriter = io.getOut();

        cmd = new ArrayList<String>();
        //Actual code reformatting happens here
        cmd.add("perltidy");
        cmd.add("-b");
        cmd.add(fileName);

        procBuilder = new ProcessBuilder(cmd);
        procBuilder.redirectErrorStream(true);

        try {
            process = procBuilder.start();
            InputStream is = process.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);

            outputWriter.reset();
            outputWriter.printf("Perl::Tidy Result :\n");
            outputWriter.printf("Tidying file : " + fileName.toString() + "....\n");
            outputWriter.printf("Done\n");
//          outputWriter.printf("Original file backed up as *.pl.bak.\n");
        } catch (IOException ex) {
            Exceptions.printStackTrace(ex);
        }
    }


}
