/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.dev.languages.perl.compiler;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.openide.filesystems.FileUtil;
import org.openide.loaders.DataObject;
import org.openide.util.Exceptions;
import org.openide.windows.IOProvider;
import org.openide.windows.InputOutput;
import org.openide.windows.OutputWriter;

/**
 *
 * @author Administrator
 */
public class PerlCompiler {
    DataObject dataObject;
    String fileName;

    public PerlCompiler() {
        this.dataObject = null;
    }

    public void compileDataObject(DataObject dObj) {
        ProcessBuilder procBuilder;
        Process process;
        Map<String, String> env;

        List<String> cmd;
        String line;
        InputOutput io;
        OutputWriter outputWriter;

        this.dataObject = dObj;
        File file = FileUtil.toFile(dObj.getPrimaryFile());
        fileName = file.getAbsolutePath();

        io = IOProvider.getDefault().getIO("Perl", false);
        io.select();
        outputWriter = io.getOut();

        cmd = new ArrayList<String>();
        cmd.add("perl");
        cmd.add("-w");
        cmd.add(fileName);

        procBuilder = new ProcessBuilder(cmd);
        procBuilder.redirectErrorStream(true);
        procBuilder.directory(file.getParentFile());

        try {
            process = procBuilder.start();
            InputStream is = process.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);

            outputWriter.reset();
            outputWriter.printf("Script Output :\n");
            outputWriter.printf("Executing file : " + fileName.toString() + "\n\n");
            while ((line = br.readLine()) != null) {
                outputWriter.println(line);
            }
        } catch (IOException ex) {
            Exceptions.printStackTrace(ex);
        }
    }

}
